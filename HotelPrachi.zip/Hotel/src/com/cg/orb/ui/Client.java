package com.cg.orb.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.orb.dto.RoomRegistrationDetails;
import com.cg.orb.service.*;

public class Client {
	static Scanner sc = new Scanner(System.in);
	
	
public static void main(String[] args) throws SQLException, IOException {
	
	System.out.println("Room Booking Application");
	while(true){
		System.out.println("1.Booking Room \n2.Exit");
		System.out.println("Enter choice");
		int choice = sc.nextInt();
		switch(choice){
		case 1 :getBookingDetails();
				break;
		case 2 : System.exit(0);
		}
	}
	
}

private static void getBookingDetails() throws SQLException, IOException {
	ArrayList<Integer> list = new ArrayList<Integer>();
	IRoomRegistrationService service = new RoomRegistrationServiceImpl();
	list = service.getAllOwnerIds();
	System.out.println("Existing HotelOwner IDS Are:-"+list);
	System.out.println("Please enter your hotel owner id   from above list:");
	int id = sc.nextInt();
	System.out.println("Select  room type Type (1-1AC, 2-2NON-AC):");
	int type = sc.nextInt();
	System.out.println("Enter room area in sq. ft.");
	int area = sc.nextInt();
	System.out.println("Enter desired rent amount Rs: ");
	float rent = sc.nextFloat();
	System.out.println("Enter desired paid amount Rs: ");
	float paid = sc.nextFloat();
	RoomRegistrationDetails rd  = new RoomRegistrationDetails(id,type,area,rent,paid);
	IRoomRegistrationService rs = new RoomRegistrationServiceImpl();
	int res = rs.registerRoom(rd);
	System.out.println("Thank you. your Room no is"+res);
}
}
