package com.cg.orb.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.orb.dao.*;
import com.cg.orb.dto.RoomRegistrationDetails;


public class RoomRegistrationServiceImpl implements IRoomRegistrationService{

	IRoomRegistrationDAO rdao;
	@Override
	public int  registerRoom(RoomRegistrationDetails flat) throws SQLException, IOException {
		rdao=new RoomRegistrationDAOImpl();
		return rdao.registerRoom(flat);
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() throws SQLException, IOException {
		rdao=new RoomRegistrationDAOImpl();
		return rdao.getAllOwnerIds();
	}

}
