package com.cg.orb.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.orb.dto.RoomRegistrationDetails;

public interface IRoomRegistrationService {
	int registerRoom(RoomRegistrationDetails flat) throws SQLException, IOException;
	ArrayList<Integer> getAllOwnerIds() throws SQLException, IOException;
}
