package com.cg.orb.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.orb.dto.RoomRegistrationDetails;

public interface IRoomRegistrationDAO {
	int registerRoom(RoomRegistrationDetails flat) throws SQLException, IOException;
	ArrayList<Integer> getAllOwnerIds() throws SQLException, IOException;
}
