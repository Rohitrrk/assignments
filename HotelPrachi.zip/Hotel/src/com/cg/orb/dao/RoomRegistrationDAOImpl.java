package com.cg.orb.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.orb.DbUtil.DbUtil;
import com.cg.orb.dto.RoomRegistrationDetails;

public class RoomRegistrationDAOImpl implements IRoomRegistrationDAO{

	Connection con;
	PreparedStatement  ps;
	ArrayList<RoomRegistrationDetails> arr = new ArrayList<RoomRegistrationDetails>();
	
	
	@Override
	public int registerRoom(RoomRegistrationDetails flat) throws SQLException, IOException {
		// TODO Auto-generated method stub
		int res=0;
		con = DbUtil.getConnection();
		RoomRegistrationDetails rd = new RoomRegistrationDetails();
		String str ="insert into Room_Registration values(room_seq.nextval,?,?,?,?,?)";
		ps=con.prepareStatement(str);
		ps.setInt(1,flat.getHotelOwnId());
		ps.setInt(2,flat.getRoomType());
		ps.setInt(3,flat.getRoomArea());
		ps.setFloat(4,flat.getRentAmt());
		ps.setFloat(5,flat.getPaidAmt());
		ps.executeUpdate();
		String str1="select room_seq.currval from dual";
		PreparedStatement ps1=con.prepareStatement(str);
		ResultSet rs = ps1.executeQuery();
		while(rs.next()){
			res = rs.getInt(1);
		}
		return res;
	}

	
	@Override
	public ArrayList<Integer> getAllOwnerIds() throws SQLException, IOException {
		
		ArrayList<Integer> arr = new ArrayList<Integer>();
		con = DbUtil.getConnection();
		String str ="select hotel_ID from Hotel_owners";
		ps=con.prepareStatement(str);
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
		int rr=rs.getInt(1);
		arr.add(rr);
		}
		return arr;
	}

}
