package com.cg.orb.dto;

public class RoomRegistrationDetails {

	private int hotelOwnId;
	private int roomType;
	private int roomArea;
	private float rentAmt;
	private float paidAmt;
	
	public RoomRegistrationDetails(){
		
	}
	
	public RoomRegistrationDetails(int hotelOwnId, int roomType, int roomArea,
			float rentAmt, float paidAmt) {
		super();
		this.hotelOwnId = hotelOwnId;
		this.roomType = roomType;
		this.roomArea = roomArea;
		this.rentAmt = rentAmt;
		this.paidAmt = paidAmt;
	}
	public int getHotelOwnId() {
		return hotelOwnId;
	}
	public void setHotelOwnId(int hotelOwnId) {
		this.hotelOwnId = hotelOwnId;
	}
	public int getRoomType() {
		return roomType;
	}
	public void setRoomType(int roomType) {
		this.roomType = roomType;
	}
	public int getRoomArea() {
		return roomArea;
	}
	public void setRoomArea(int roomArea) {
		this.roomArea = roomArea;
	}
	public float getRentAmt() {
		return rentAmt;
	}
	public void setRentAmt(float rentAmt) {
		this.rentAmt = rentAmt;
	}
	public float getPaidAmt() {
		return paidAmt;
	}
	public void setPaidAmt(float paidAmt) {
		this.paidAmt = paidAmt;
	}
}
