package com.cg.student.service;

import java.util.ArrayList;

import com.cg.student.bean.StudentDetail;

public interface IStudentService 
{

	ArrayList<Integer> getId();

	StudentDetail addStudentMarks(StudentDetail bean);



}
