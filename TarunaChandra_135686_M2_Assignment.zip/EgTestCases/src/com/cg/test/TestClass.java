package com.cg.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestClass {

	@Test
	public void test() {
		Egcalc c= new Egcalc();
		int res=c.add(2, 1);
		assertEquals(3,res);
		
	}

}
