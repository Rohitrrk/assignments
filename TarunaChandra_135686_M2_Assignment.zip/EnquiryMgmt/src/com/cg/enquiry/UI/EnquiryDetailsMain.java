package com.cg.enquiry.UI;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.enquiry.bean.EnquiryDetails;
import com.cg.enquiry.service.EnquiryServiceImp;
import com.cg.enquiry.service.IEnquiryService;


public class EnquiryDetailsMain {

	static Scanner sc= new Scanner(System.in);
	static EnquiryDetails details= null;
	static IEnquiryService service= new EnquiryServiceImp();
	public static void main(String[] args) throws IOException, SQLException
	{
		
	
		while(true)
		{
		System.out.println("Choose an Operation");
		System.out.println("1.Enter Enquiry Details\n2.View Enquiry Details on ID\n0.Exit");
		System.out.println("************************");
		System.out.print("\nPlease enter a choice:");
		int choice= sc.nextInt();
		switch(choice)
			{
				case 0:
				{	System.out.println("Thank you for selection us!! ");
					System.exit(0);
					break;
				}
				case 1:
				{
					addEnquiryDetails();
					break;
				}
					
				case 2:
				{	
					getEnquiryDetailsOnId();
					break;
				}
			}
		}
}
	
	
	
	private static void getEnquiryDetailsOnId() throws IOException, SQLException 
	{
		System.out.println("Enter the Enquiry Id:");
		int eid=sc.nextInt();
		ArrayList<EnquiryDetails> list= new ArrayList<EnquiryDetails>();
		list=service.getDetails(eid);
		for(EnquiryDetails out:list)
		{
			System.out.println(out);
		}
		
		
	}
	
	
	
	private static void addEnquiryDetails() {
		PropertyConfigurator.configure("log4j.properties");
		Logger logger=Logger.getRootLogger();
		
		try
		{
		System.out.println("Enter First Name:");
		String fname=sc.next();
		
		System.out.println("Enter Last Name:");
		String lname=sc.next();
		
		System.out.println("Enter Contact no");
		int contactno=sc.nextInt();
			
		System.out.println("Enter preferred domain");
		String domain= sc.next(); 
		
		System.out.println("Enter perferred location");
		String location= sc.next();
		
		details= new  EnquiryDetails(fname,lname,contactno,domain,location);
		
		int res=service.addEnquiryDetails(details);
		
		System.out.println("Thank you"+fname+lname+ "your unique id is "+res+"we will contact you shortly.");
		
		logger.info("Executed succefully");
	}
	catch(Exception e)
	{
		
		logger.error("Exception occured"+e.getMessage());
	}
		
	}
}
