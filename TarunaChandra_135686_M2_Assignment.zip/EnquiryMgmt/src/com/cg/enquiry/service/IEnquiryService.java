package com.cg.enquiry.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.enquiry.bean.EnquiryDetails;

public interface IEnquiryService {

	public int addEnquiryDetails(EnquiryDetails details) throws IOException, SQLException;

	public ArrayList<EnquiryDetails> getDetails(int eid) throws IOException, SQLException;

}
