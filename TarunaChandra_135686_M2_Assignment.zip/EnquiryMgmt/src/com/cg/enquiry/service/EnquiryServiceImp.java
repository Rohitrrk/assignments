package com.cg.enquiry.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.enquiry.bean.EnquiryDetails;
import com.cg.enquiry.dao.EnquiryDaoImp;
import com.cg.enquiry.dao.IEnquiryDao;

public class EnquiryServiceImp implements IEnquiryService {
	IEnquiryDao dao= new EnquiryDaoImp();
	
	public int addEnquiryDetails(EnquiryDetails details) throws IOException, SQLException {
		
		dao=new EnquiryDaoImp();
		return dao.addEnquiryDetails(details);
	}

	@Override
	public ArrayList<EnquiryDetails> getDetails(int eid) throws IOException, SQLException {
		dao=new EnquiryDaoImp();
		
		return dao.getDetails(eid);
	}

}
