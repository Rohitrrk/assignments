package com.cg.enquiry.test;

public class EnquiryTest {

}
