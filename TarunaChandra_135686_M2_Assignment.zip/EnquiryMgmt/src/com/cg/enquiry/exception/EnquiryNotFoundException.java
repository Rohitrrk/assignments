package com.cg.enquiry.exception;

public class EnquiryNotFoundException {

}
