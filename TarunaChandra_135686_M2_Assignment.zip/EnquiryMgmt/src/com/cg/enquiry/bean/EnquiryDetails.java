package com.cg.enquiry.bean;

public class EnquiryDetails {

	private int enquiryid;
	private String fname;
	private String lname;
	private int contactno;
	private String domain;
	private String location;
	
	
	
	public int getEnquiryid() {
		return enquiryid;
	}
	public void setEnquiryid(int enquiryid) {
		this.enquiryid = enquiryid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public int getContactno() {
		return contactno;
	}
	public void setContactno(int contactno) {
		this.contactno = contactno;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	
	public EnquiryDetails(int enquiryid, String fname, String lname,
			int contactno, String domain, String location) {
		super();
		this.enquiryid = enquiryid;
		this.fname = fname;
		this.lname = lname;
		this.contactno = contactno;
		this.domain = domain;
		this.location = location;
	}
	
	
	public EnquiryDetails(String fname, String lname, int contactno,
			String domain, String location) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.contactno = contactno;
		this.domain = domain;
		this.location = location;
	}

	
	
	public String toString() {
		return "EnquiryDetails [enquiryid=" + enquiryid + ", fname=" + fname
				+ ", lname=" + lname + ", contactno=" + contactno + ", domain="
				+ domain + ", location=" + location + "]";
	}
	
	
	
	
}
