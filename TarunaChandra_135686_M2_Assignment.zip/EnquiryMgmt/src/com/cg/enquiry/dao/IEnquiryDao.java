package com.cg.enquiry.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.enquiry.bean.EnquiryDetails;

public interface IEnquiryDao {

	public int addEnquiryDetails(EnquiryDetails details) throws IOException, SQLException;

	public ArrayList<EnquiryDetails> getDetails(int eid) throws IOException, SQLException;

}
