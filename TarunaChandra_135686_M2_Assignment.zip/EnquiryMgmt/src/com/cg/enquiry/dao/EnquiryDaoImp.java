package com.cg.enquiry.dao;

import java.beans.Statement;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.enquiry.bean.EnquiryDetails;
import com.cg.enquiry.util.DbUtil;

public class EnquiryDaoImp implements IEnquiryDao {


	int res;
	int result;
	public int addEnquiryDetails(EnquiryDetails details) throws IOException, SQLException 
	{
		Connection con= DbUtil.getConnection();
		
		String insertQuery="insert into enquiry values(enq_id.nextval,?,?,?,?,?)";
		PreparedStatement ps= con.prepareStatement(insertQuery);
		
		ps.setString(1, details.getFname());
		ps.setString(2,details.getLname());
		ps.setInt(3, details.getContactno());
		ps.setString(4, details.getDomain());
		ps.setString(5, details.getLocation());
		
		res= ps.executeUpdate();
		
		if(res==1)
		{
			String sql="select enquiryid from enquiry where firstname=? and lastname=?";
			PreparedStatement pst= con.prepareStatement(sql);
			pst.setString(1, details.getFname());
			pst.setString(2,details.getLname());
			
			ResultSet rs=pst.executeQuery();
			 while(rs.next())
			 {
				result = rs.getInt(1);
			 }
		 }
		 else
		 {
			 return 0;
		 }
			return result;
		}
	@Override
	public ArrayList<EnquiryDetails> getDetails(int eid) throws IOException, SQLException {
		Connection con= DbUtil.getConnection();
		ArrayList<EnquiryDetails> list= new ArrayList<EnquiryDetails>();
		String selectQuery="Select * from enquiry where enquiryid=?";
		PreparedStatement pstm= con.prepareStatement(selectQuery);
		pstm.setInt(1, eid);
		ResultSet res= pstm.executeQuery();
		while(res.next())
		{
			int enqid= res.getInt(1);
			String fname = res.getString(2);
			String lname = res.getString(3);
			int contactNo = res.getInt(4);
			String domain = res.getString(5);
			String location = res.getString(6);		
			
			list.add(new EnquiryDetails(enqid,fname,lname,contactNo,domain,location));
		}
		
		
		
		return list;
	}
}


