package com.cg.enquiry.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.enquiry.bean.EnquiryDetails;
import com.cg.enquiry.dbutil.DbUtil;


public class EnquiryDaoImp implements IEnquiryDAO{

	EnquiryDetails ed= null;
	Connection conn= null;	
	
	public int addEnquiryDetails(EnquiryDetails ed) throws IOException, SQLException {
		conn= DbUtil.getConnection();
		String insertQuery="Insert into enquiry values(enquiry_id.nextval,?,?,?,?,?)";
		PreparedStatement pst=conn.prepareStatement(insertQuery);
		pst.setString(1,ed.getFirstName());
		pst.setString(2, ed.getLastName());
		pst.setInt(3,ed.getContactNo());
		pst.setString(4,ed.getDomain());
		pst.setString(5, ed.getCity());
		
		int res = pst.executeUpdate();
		
		return res;
		
		
		
	}

//	@Override
//	public void getAllDetails(int e_id) {
//		
//		conn= DbUtil.getConnection();
//		EnquiryDetails ed= new EnquiryDetails();
//		
//		String sql="Select * from enquiry where e_id=?";
//		PreparedStatement pst=conn.prepareStatement(sql);
//		pst.setInt(1,e_id);
//		ResultSet rs=pst.executeQuery(sql);
//		
//		while(rs.next())
//		{
//			
//			ed.setEnquiryId(rs.getInt(1));
//			ed.setFirstName(rs.getString(2));
//			ed.setLastName(rs.getString(3));
//			ed.setContactNo(rs.getInt(4));
//			ed.setDomain(rs.getString(5));
//			ed.setCity(rs.getString(6));
//		}	
//		return ed;
//	}

	


	
	
//	public ArrayList<EnquiryDetails> getAllEnquiryDetailsById() throws IOException, SQLException {
//	
//		conn= DbUtil.getConnection();
//		EnquiryDetails ed;
//		String sql="Select * from enquiry";
//		Statement ps=conn.createStatement();
//		ResultSet rst= ps.executeQuery(sql);
//		ArrayList<EnquiryDetails> lst= new ArrayList<EnquiryDetails>();
//		while(rst.next())
//		{
//			ed=new EnquiryDetails();
//			ed.setEnquiryId(rst.getInt(1));
//			ed.setFirstName(rst.getString(2));
//			ed.setLastName(rst.getString(3));
//			ed.setContactNo(rst.getInt(4));
//			ed.setDomain(rst.getString(5));
//			ed.setCity(rst.getString(6));
//			lst.add(ed);
//		}	
//		return lst;}
		
		


	@Override
	public ArrayList<EnquiryDetails> getAllEnquiryDetailsById(int eid) throws IOException, SQLException {
		conn=DbUtil.getConnection();
		ArrayList<EnquiryDetails> lst= new ArrayList<EnquiryDetails>();
		String sql="Select * from enquiry where e_id=?";
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1,eid);
		ResultSet rs=pst.executeQuery(sql);
		ed= new EnquiryDetails();
		while(rs.next())
		{
			
			
			String fname=rs.getString(2);
			String lname=rs.getString(3);
			int contactno=rs.getInt(4);
			String domain=rs.getString(5);
			String city=rs.getString(6);
			lst.add(new EnquiryDetails(fname,lname,contactno,domain,city));
			
		}	
		return lst;
	}




	
}
