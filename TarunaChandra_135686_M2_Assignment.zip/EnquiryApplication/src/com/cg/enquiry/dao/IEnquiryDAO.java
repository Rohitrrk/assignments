package com.cg.enquiry.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.enquiry.bean.EnquiryDetails;

public interface IEnquiryDAO {

	

	int addEnquiryDetails(EnquiryDetails ed) throws IOException, SQLException;


	ArrayList<EnquiryDetails> getAllEnquiryDetailsById(int eid) throws IOException, SQLException;


	

	

	

}
