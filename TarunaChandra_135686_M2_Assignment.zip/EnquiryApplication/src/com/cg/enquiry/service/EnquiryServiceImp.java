package com.cg.enquiry.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.enquiry.bean.EnquiryDetails;
import com.cg.enquiry.dao.EnquiryDaoImp;
import com.cg.enquiry.dao.IEnquiryDAO;

public class EnquiryServiceImp implements IEnquiryService{

	IEnquiryDAO dao=null;

	public int addEnquiryDetails(EnquiryDetails ed) throws IOException, SQLException {
		dao= new EnquiryDaoImp();
		return dao.addEnquiryDetails(ed);
	}

	
	
	
	public boolean validateFirstName(String name)
	{
		
		if(name.isEmpty())
			return true;
		else
			return false;
	}
	
	public boolean validateLocation(String location)
	{
		
		if(location.isEmpty())
			return true;
		else
			return false;
	}
	
	public boolean validateContactNum(String cno)
	{
		String ptrn="[0-9]{10}";
		if(Pattern.matches(ptrn, cno))
			return true;
		else
			return false;
	}





	public ArrayList<EnquiryDetails> getAllEnquiryDetailsById()
			throws IOException, SQLException {
		// TODO Auto-generated method stub
		return null;
	}





	public ArrayList<EnquiryDetails> getAllEnquiryDetailsById(int eid)
			throws IOException, SQLException {
		dao= new EnquiryDaoImp();
		return dao.getAllEnquiryDetailsById(eid);
	
	}








}
