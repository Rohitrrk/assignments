package com.cg.enquiry.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.enquiry.bean.EnquiryDetails;

public interface IEnquiryService {

	public int addEnquiryDetails(EnquiryDetails ed) throws IOException, SQLException;
	public ArrayList<EnquiryDetails> getAllEnquiryDetailsById() throws IOException, SQLException;
	public boolean validateLocation(String location);
	public boolean validateFirstName(String fname);
	public ArrayList<EnquiryDetails> getAllEnquiryDetailsById(int eid) throws IOException, SQLException;

}
