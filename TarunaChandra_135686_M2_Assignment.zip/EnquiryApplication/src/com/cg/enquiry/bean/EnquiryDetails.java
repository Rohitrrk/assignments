package com.cg.enquiry.bean;

public class EnquiryDetails {

	private int enquiryId;
	private  String firstName;
	private String lastName;
	private int contactNo;
	private String domain;
	private String city;
	
	
	
	public int getEnquiryId() {
		return enquiryId;
	}
	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getContactNo() {
		return contactNo;
	}
	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
	
	public String toString() {
		return "EnquiryDetails [firstName="
				+ firstName + ", lastName=" + lastName + ", contactNo="
				+ contactNo + ", domain=" + domain + ", city=" + city + "]";
	}
	
	
	
	public EnquiryDetails(String firstName, String lastName,
			int contactNo, String domain, String city) {
		super();
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.contactNo = contactNo;
		this.domain = domain;
		this.city = city;
	}
	public EnquiryDetails(int enquiryid,String firstName, String lastName,
			int contactNo, String domain, String city) {
		super();
		this.enquiryId=enquiryid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.contactNo = contactNo;
		this.domain = domain;
		this.city = city;
	}
	public EnquiryDetails() {
		// TODO Auto-generated constructor stub
	}
	
	
}
