import java.util.ArrayList;
import java.util.Collections;


public class Main {

	public static void main(String[] args) {
		ArrayList<Employee1> a1= new ArrayList<Employee1>();
		a1.add(new Employee1(101,"nimmy",25000));
		a1.add(new Employee1(100,"namoh",15000));
		a1.add(new Employee1(102,"nim",5000));
		
		Collections.sort(a1, new sortAll());	
		System.out.println("based on Employee id sorting");
		
		for(Employee1 e:a1)
			System.out.println(e);
	}
	
//	System.out.println("based on Employee salary sorting");
//	Collections.sort(a1,new SortBySalary());
//	
//	
//	for(Employee1 e1:a1)
//		System.out.println(e1);

	}

