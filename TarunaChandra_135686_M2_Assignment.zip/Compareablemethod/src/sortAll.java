import java.util.Comparator;


public class sortAll implements Comparator<Employee1>{
	
	public int compare(Employee1 e1, Employee1 e2)
	{
		
		return e1.geteID()-e2.geteID();	
			
	}
	
}
