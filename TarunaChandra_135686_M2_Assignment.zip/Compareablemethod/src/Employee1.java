
public class Employee1 implements Comparable <Employee1>{
	int eID;
	String eName;
	int salary;
	
	public Employee1(int eID, String eName, int salary) {
		super();
		this.eID = eID;
		this.eName = eName;
		this.salary = salary;
	}
	
	public int geteID() {
		return eID;
	}

	public void seteID(int eID) {
		this.eID = eID;
	}

	public String geteName() {
		return eName;
	}

	public void seteName(String eName) {
		this.eName = eName;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}


	public String toString() {
		return "Employee1 [eID=" + eID + ", eName=" + eName + ", salary="
				+ salary + "]";
	}


	public int compareTo(Employee1 e) {
		if(salary==e.salary)
			return 0;
		else if(salary>e.salary)
			return 1;
		else
			return -1;
	}

	}

	



