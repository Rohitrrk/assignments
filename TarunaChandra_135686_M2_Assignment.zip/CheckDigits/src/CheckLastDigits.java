import java.util.Scanner;

public class CheckLastDigits {

	
	
	public static void main(String[] args) {
		int firstnumber;
		int secondnumber;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number 1:");
		firstnumber= sc.nextInt();
		System.out.println("Enter number 2:");
		secondnumber= sc.nextInt();
		int rem1= firstnumber%10;
		int rem2= secondnumber%10;
		if(rem1==rem2)
			System.out.println("TRUE");
		else
			System.out.println("FALSE");
		
	}
	
}
