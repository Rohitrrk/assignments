
public class User {
 public static boolean display(int num1, int num2)
 {
	 int rem1= num1%10;
	int rem2= num2%10;
	if(rem1==rem2)
		return true;
	else
		return false;
 }
}
