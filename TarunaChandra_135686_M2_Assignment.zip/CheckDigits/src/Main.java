import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		  
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number 1:");
		int firstnumber= sc.nextInt();
		System.out.println("Enter number 2:");
		int secondnumber= sc.nextInt();
		System.out.println(""+User.display(firstnumber, secondnumber));
		sc.close();
	}
}