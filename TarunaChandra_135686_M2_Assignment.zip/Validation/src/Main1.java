
public class Main1 {

	public static void checkAge(int age)
	{
		if(age>13)
		{
			throw new ArithmeticException("invalid age");
		}
		else
		{
			System.out.println("valid age");
		}
	}
	public static void main(String[] args) {
		try
		{
			Main1.checkAge(16);
	
		}
		catch(Exception e)
		{
			System.out.println("age error");
		}
	}
}
