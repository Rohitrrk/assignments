
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


//public class ThrowsClass {
//	public static void main(String[] args) throws ParseException
//	{
//		String s="10-12-2017";
//		SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy");
//		Date d1=sdf.parse(s);
//		System.out.println(d1);
//	}
//
//}


public class ThrowsClass {
	public static void main(String[] args) 
	{
		String s="10-12-2017";
		SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy");
		Date d1;
		try {
			d1 = sdf.parse(s);
		} 
		catch (ParseException e) 
		{
			System.out.println("invalid date");
			e.printStackTrace();
		}
		
	}
}
