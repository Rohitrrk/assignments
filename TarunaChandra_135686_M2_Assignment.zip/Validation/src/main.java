import java.util.regex.Pattern;


public class Main {

	public static void main(String[] args) {
		String s="capgemini";
		String pattern= "[a-z]{2,}";
		boolean a=Pattern.matches(pattern, s);
		String phno="9869745321";
		String reg="[789]{1}[0-9]{9}";
		boolean b= Pattern.matches(reg, phno);
		String digitinput="98";
		String digit = "[0-9]*";
		boolean c=Pattern.matches(digit,digitinput);
		String pat="Aabhds";
		String pt="[A-Z]{1}[a-z]*";
		boolean d=Pattern.matches(pt,pat);
		System.out.println("\n"+a+"\n"+b);
		System.out.println(""+c+"\n"+d);
	}
}
