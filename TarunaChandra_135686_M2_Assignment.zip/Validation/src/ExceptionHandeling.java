
public class ExceptionHandeling {

	public static void main(String[] args) {
		try
		{
			int a=10/0;
			int b[]=new int[5];
			b[2]=90;
		}
//		catch(ArithmeticException e)
//		{
//			System.out.println("invalid output");
//		}
		catch(ArrayIndexOutOfBoundsException | ArithmeticException e)
		{
			e.printStackTrace();
		}
		finally
		{
			
			System.out.println("Always execute");
			System.exit(0);
		}
	}
}
