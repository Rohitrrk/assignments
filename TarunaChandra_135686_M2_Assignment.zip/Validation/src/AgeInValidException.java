
public class AgeInValidException {
	extends Exception{
		public AgeInValidException(String age)
		{
			super(age);
		}
	}

