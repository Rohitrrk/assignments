


public class UserDefinedException {
	
	static void ageCheck(int age) throws AgeInValidException	
	{
		
	}

	public static void main(String[] args) 
		{
			try
			{
				ageCheck(-2);
			}
			catch(AgeInValidException a)
			{
				System.out.println(a);
			}
		}
}
