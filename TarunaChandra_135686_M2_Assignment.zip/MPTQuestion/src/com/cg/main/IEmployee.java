package com.cg.main;

interface IEmployee 
{

	void display();
	void insert();
	void retrival();
	
}
