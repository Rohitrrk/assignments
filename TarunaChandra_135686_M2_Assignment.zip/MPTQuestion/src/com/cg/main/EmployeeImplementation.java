package com.cg.main;


class EmployeeImplementation implements  IEmployee 
{

	public void display()
	{
		System.out.println("this is the display method");
	}
	
	public void insert()
	{
		System.out.println("employee insert method");
	}

	public void retrival() {
		System.out.println("this is retrevial method");
		
	}
}

class Main{
	public static void main(String[] args) {
		EmployeeImplementation ei= new EmployeeImplementation();
		ei.display();
		ei.insert();
		ei.retrival();
	}
}

