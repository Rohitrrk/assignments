import java.util.Scanner;


public class PositiveString {

	void display(String s)
	{
		int i;
		int j;
		int n=0;
		int m=0;
		char ch,ch1;
		for(i=0;i<s.length();i++)
		{
			
				ch=s.charAt(i);
				ch1=s.charAt(i+1);
				if(ch<ch1)
					n=1;
					
				else
					m=1;
			
		}
		if(m==1 && n==1)
			System.out.println("String is negative");
		else 
			System.out.println("String is positive");
	}
	
}



class main
{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a string");

		String str= sc.next();
		PositiveString ps= new PositiveString();
		ps.display(str);
		sc.close();
	}
}