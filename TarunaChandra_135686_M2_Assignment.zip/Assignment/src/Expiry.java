import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class Expiry {

//	void accept()
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter product purhcase date");
		String prdt= sc.next();
		System.out.println("Enter the warranty period");
		String warran= sc.next();
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate pd=LocalDate.parse(prdt, formatter);
		LocalDate wp=LocalDate.parse(warran, formatter);
		
	}
}