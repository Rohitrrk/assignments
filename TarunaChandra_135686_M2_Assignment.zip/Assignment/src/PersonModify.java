

import java.util.Scanner;



public class PersonModify {

		public static void main(String[] args) 
		{
			Details d=new Details();
			d.AcceptInput();
			d.display();
		}
}



class Details
{

	Scanner sc= new Scanner(System.in);
	String firstname;
	String lastName;
	char gender;
	long phno;
	
	void AcceptInput()
	{
		System.out.println("Enter the First name:");
		 firstname= sc.next();
		
		System.out.println("Enter the Last name:");
		 lastName= sc.next();
		
		System.out.println("Enter the gender:");
		 gender=sc.next().charAt(0);
		
		System.out.println("Enter the phone number");
		 phno= sc.nextLong();
		
	}
	
	
	 void display()
	{
		
		System.out.println("First name:"+firstname+"\nLast name:"+lastName+"\ngender:"+gender+"\nPhone number:"+phno);

	}
}