
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;


public class LabSevenTwo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ArrayList<String> arr_name=new ArrayList<String>();
		
		System.out.println("Enter the number of names you want to enter");
		int n=sc.nextInt();
		String name;
		
		for(int i=0;i<n;i++)
		{
			name = sc.next();
		arr_name.add(name);
		}
		
		Collections.sort(arr_name);
			
		System.out.println("names sorted in alphabetical order are:");
			
		for(String a:arr_name)
			System.out.println(a);
		}
	}


