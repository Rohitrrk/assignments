import java.util.Arrays;
import java.util.Scanner;


public class ArrayString {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of names you want to enter");
		int n=sc.nextInt();
		String names[]= new String[n];
		
		for(int i=0;i<n;i++)
			names[i]=sc.next();
		
		Arrays.sort(names);
		
		System.out.println("names sorted in alphabetical order are:");
		
		for(int i=0;i<names.length;i++)
			System.out.println(names[i]);
	}
}
