
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

class DateDisp
{
	Period period;

	void accept()
	{
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter starting Date");
		String date1= sc.next();
		System.out.println("Enter ending Date");
		String date2= sc.next();
		LocalDate d1 =LocalDate.parse(date1, formatter);
		LocalDate d2=LocalDate.parse(date2, formatter);
		period=d1.until(d2);
		sc.close();
		
	}
	
	void display()
	{
		System.out.println("Days:"+period.get(ChronoUnit.DAYS));
		System.out.println("Months:"+period.get(ChronoUnit.MONTHS));
		System.out.println("Years:"+period.get(ChronoUnit.YEARS));
	}
}

public class DurationDates
{
	public static void main(String[] args) {
		DateDisp df= new DateDisp();
		df.accept();
		df.display();
	}
}