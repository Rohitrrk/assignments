import java.util.Scanner;

class Operation{
	void add(String s)
	{
		String s1=s.concat(s);
		System.out.println(s1);
	}
	void replacechar(String s)
	{
		int i;
		String s1="";
		char ch = '#';
		
		for(i=0;i<s.length();i++)
		{
			if(i % 2 == 0)
				s1=s1+s.charAt(i);
			else
				s1=s1+ch;
			
		}
		System.out.println(s1);
	}
	void removeduplicate(String s)
	{
		int i;
		String s1="";
		char ch;
		for(i=0;i<s.length();i++)
		{
			 ch = s.charAt(i);
	            if(ch!=' ')
	                s1 = s1 + ch;
	            s = s.replace(ch,' ');;
				
				
		}
		System.out.println(s1);
	}
	void uppercase(String s)
	{
		int i;
		char ch;
		for(i=0;i<s.length();i++)
		{
			ch=s.charAt(i);
			if(i % 2 != 0)
				System.out.print(Character.toUpperCase(ch));
			else
				System.out.print(Character.toLowerCase(ch));
		}
	
	}	
}

public class StringOperation {
 public static void main(String[] args) {
	 
	Scanner sc = new Scanner(System.in);
	Operation p=new Operation();
	
	System.out.println("Enter the choice:\n1.Add the String to itself\n2.Replace odd position with #\n3.Remove duplicate characters in the String\n4.Change odd characters to upper case");
	int ch= sc.nextInt();
	
	System.out.println("Enter the string");
	String str= sc.next();
	
	 
	switch(ch)
	
	{
	case 1:
	{
		p.add(str);
		break;
	}
	case 2:
	{
		p.replacechar(str);
		break;
	}
	case 3:
	{	
		p.removeduplicate(str);
		break;
	}
	case 4:
	{
		p.uppercase(str);
		break;
	}	
	}
	
}
}

