import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

class DateDisplay
{
	Period period;

	void acceptData()
	{
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Date");
		String date= sc.next();
		LocalDate d=LocalDate.parse(date, formatter);
		System.out.println(d);
		LocalDate d1= LocalDate.now();
		period=d.until(d1);
		
	}
	
	void display()
	{
		System.out.println("Days:"+period.get(ChronoUnit.DAYS));
		System.out.println("Months:"+period.get(ChronoUnit.MONTHS));
		System.out.println("Years:"+period.get(ChronoUnit.YEARS));
	}
}

class AcceptDate
{
	public static void main(String[] args) {
		DateDisplay dd= new DateDisplay();
		dd.acceptData();
		dd.display();
	}
}