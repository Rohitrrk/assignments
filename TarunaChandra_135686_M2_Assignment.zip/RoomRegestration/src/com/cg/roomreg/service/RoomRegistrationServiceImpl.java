package com.cg.roomreg.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.roomreg.bean.RoomRegistrationDTO;
import com.cg.roomreg.dao.IRoomRegistrationDAO;
import com.cg.roomreg.dao.RoomRegistrationDAOImpl;
import com.cg.roomreg.exception.RoomRegistrationException;

public class RoomRegistrationServiceImpl implements IRoomRegistrationService {

	IRoomRegistrationDAO dao= new RoomRegistrationDAOImpl();
	public int addRoomDetails(RoomRegistrationDTO details)  throws RoomRegistrationException {
		return dao.RoomRegistrationDAOImpl(details);
	
	}
	ArrayList<Integer> al = new ArrayList<Integer>();
	public ArrayList<Integer> gethotelbyIds() throws SQLException, IOException {
		al = dao.gethotelbyIds();
		return al;
	}
	
	public boolean validateAmount(int paid_amount, int rent_amount)
	{
		if(paid_amount>rent_amount)
			return true;
		else
			return false;
	}

	public boolean validatePaidAmount(int paid_amount)
	{
		if(paid_amount>0)
			return true;
		else
			return false;
	}
	
	public boolean validateRentAmount(int rent_amount)
	{
		if(rent_amount>0)
			return true;
		else
			return false;
	}

	public boolean validateRoom_area(int room_area) {
		int ra=room_area;
		if(ra>100 && ra<1000)
			return true;
		else
			return false;
	}

	public boolean validateRoom_type(int room_type) {
		int rt=room_type;
		if(rt==1 || rt==2)
			return true;
		else
			return false;
	}

	public boolean validateHotel_id(int hotel_id) {
		if(al.contains(hotel_id))
			return true;
		else
			try {
				throw new RoomRegistrationException(hotel_id);
			} catch (RoomRegistrationException e) {
				
				System.out.println(e);
			}
		return false;
			
	}

}