package com.cg.roomreg.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.roomreg.bean.RoomRegistrationDTO;
import com.cg.roomreg.exception.RoomRegistrationException;

public interface IRoomRegistrationService {

	public int addRoomDetails(RoomRegistrationDTO details) throws RoomRegistrationException;

	public ArrayList<Integer> gethotelbyIds() throws SQLException, IOException;

	public boolean validateHotel_id(int hotelid);

	public boolean validateAmount(int paid_amount, int rent_amount);
	
	public boolean validatePaidAmount(int paid_amount);
	
	public boolean validateRentAmount(int rent_amount);

	public boolean validateRoom_area(int room_area);
	
	public boolean validateRoom_type(int room_type);
}
