package com.cg.roomreg.test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.roomreg.bean.RoomRegistrationDTO;
import com.cg.roomreg.dao.IRoomRegistrationDAO;
import com.cg.roomreg.dao.RoomRegistrationDAOImpl;



public class RoomRegistrationTest {

	static IRoomRegistrationDAO dao=null;
	static RoomRegistrationDTO bean=null;

	@BeforeClass
	public static void initalize() 
	{
		System.out.println("Hi");
		dao=new RoomRegistrationDAOImpl();
		bean=new RoomRegistrationDTO();
	}

	@Test
	public void test() 
	{
		bean.setHotel_id(124);
		bean.setRoom_no(1001);
		bean.setRoom_type(2);
		bean.setRoom_area(452);
		bean.setRent_amount(4500);
		bean.setPaid_amount(5200);
	}
	
	@Test
	public void testAddDetails() throws SQLException, IOException
	{
		assertNotNull(dao.gethotelbyIds());
	}

}
