package com.cg.roomreg.exception;

public class RoomRegistrationException extends Exception{
	
	@Override
	public String toString() {
		return "RoomRegistrationException [d=" + d + "]";
	}
	
	int d;
	public RoomRegistrationException(int data) {
		d=data;
		System.out.println("\nDatabase doesnot contain the hotelid "+d+",Please enter a valid hotel id!");
	}

}
