import java.util.Scanner;
enum gender{
	MALE,FEMALE;
}

public class Enumgender {
	
public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the gender");
	char gen= sc.next().charAt(0);
	if(gen =='M' || gen=='m')
		System.out.println(" "+gender.MALE);
	else if(gen=='F' || gen =='f')
		System.out.println(""+gender.FEMALE);
	else
		System.out.println("Wrong input");
}

}
