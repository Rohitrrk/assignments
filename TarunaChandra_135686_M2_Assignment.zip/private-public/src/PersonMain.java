import java.util.Scanner;
public class PersonMain{

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		Person p = new Person();
		System.out.println("Enter the First name:");
		String firstname= sc.next();
		p.setFirstName(firstname);
		System.out.println("Enter the Last name:");
		String lastName= sc.next();
		p.setLastName(lastName);
		System.out.println("Enter the gender:");
		char gender=sc.next().charAt(0);
		p.setGender(gender);
		System.out.println("First name:"+p.getFirstName()+"\nLast name:"+p.getLastName()+"\ngender:"+p.getGender());
	}
}
