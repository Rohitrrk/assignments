package com.cg.mobile.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mobile.DAO.IMobileDAO;
import com.cg.mobile.DAO.MobileDaoImp;
import com.cg.mobile.DTO.MobileDetails;
import com.cg.mobile.DTO.PurchaseDetails;
import com.cg.mobile.exception.MobileApplicationException;

public class MobileServiceImp implements IMobileService {

	IMobileDAO dao=null;
	public int addPurchaseDetails(PurchaseDetails p) throws MobileApplicationException
	{
		dao=new MobileDaoImp();
		return dao.addPurchaseDetails(p);
	}
	
	
	public boolean validateName(String name)
	{
		String ptn="[A-Z]{1}[a-z]{2,19}";
		if(Pattern.matches(ptn, name))
		{
			return true;
		}
		else
		{
			System.out.println("Please Enter valid details");
			return false;
		}
	}
	
	public boolean validateEmailId(String email)
	{
		String eptn="^[?=.*A-Za-z0-9]+@[A-Za-z]+\\.[A-Za-z]{2,6}$";
		if(Pattern.matches(eptn, email))
		{
			return true;
		}
		else
		{
			System.out.println("Please Enter valid details");
			return false;
		}
	}
	
	public boolean validPhoneNo(String phno)
	{
		String phptn="[0-9]{10}";
		if(Pattern.matches(phptn,phno))
		{
			return true;
		}
		else
		{
			System.out.println("Please Enter valid details");
			return false;
		}	
	}
	public boolean validMobileId(String mid)
	{
		String mobid="[0-9]{4}";
		if(Pattern.matches(mobid,mid))
		{
			return true;
		}
		else
		{
			System.out.println("Please Enter valid details");
			return false;
		}	
	}

//	public int checkIdExists(String mid)
//	{
//		int r=dao.checkIdExists(mid);
//	}

	@Override
	public ArrayList<MobileDetails> retrieveDetails() throws IOException, SQLException {
		
		IMobileDAO details= new MobileDaoImp();
			return details.retrieveDetails();
		
		}
	}
	

