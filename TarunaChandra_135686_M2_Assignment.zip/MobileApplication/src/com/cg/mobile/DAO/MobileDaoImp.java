package com.cg.mobile.DAO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobile.DTO.MobileDetails;
import com.cg.mobile.DTO.PurchaseDetails;
import com.cg.mobile.dbutil.DbUtil;
import com.cg.mobile.exception.MobileApplicationException;




public class MobileDaoImp implements IMobileDAO{

int result;
Connection conn= null;	


	public int addPurchaseDetails(PurchaseDetails p) throws MobileApplicationException
	{
		PropertyConfigurator.configure("log4j.properties");
		Logger logger=Logger.getRootLogger();

		try {
			conn=DbUtil.getConnection();
			String insertQuery="Insert into PurchaseDetails values(purchase_seq_id.nextval,?,?,?,SYSDATE,?)";
			PreparedStatement ps=conn.prepareStatement(insertQuery);
			ps.setString(1,p.getcName());
			ps.setString(2, p.getMailId());
			ps.setLong(3,p.getPhoneNo());
			ps.setInt(4, p.getMobileId());
			
			result = ps.executeUpdate();
			logger.info("Executed succefully");
			
	/*		String sql="select mobileid from mobiles where mobileid=?";
			PreparedStatement pst= conn.prepareStatement(sql);
			
			pst.setInt(1, p.getMobileId());
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				ps.setInt(4, rs.getInt(1));
				result=ps.executeUpdate();
				System.out.println(result);
			}
	*/	} 
		
		
		
		catch (IOException e) 
		{
			
			e.printStackTrace();
			logger.error("Exception occured"+e.getMessage());
		} 
		
		catch (SQLException e) 
		{
			
			
			logger.error("Exception occured"+e.getMessage());
		}
		
		return result;
	}


	public ArrayList<MobileDetails> retrieveDetails()  {
		PropertyConfigurator.configure("log4j.properties");
		Logger logger=Logger.getRootLogger();
		
		ArrayList<MobileDetails> list= new ArrayList<MobileDetails>();
		try
		{
			conn= DbUtil.getConnection();
			String sql="Select * from mobiles";
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(sql);
			MobileDetails mobile=null;
			while(rs.next())
			{
				int mobileId=rs.getInt(1);
				String name=rs.getString(2);
				int price=rs.getInt(3);
				String quantity= rs.getString(4);
				list.add(new MobileDetails(mobileId,name,price,quantity));
			}
		}
		
		catch(SQLException | IOException e)
		{
			System.out.println(e.getMessage());
			logger.error("Exception occured"+e.getMessage());
		}
		return list;
		
	
	}

}
