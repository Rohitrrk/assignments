package com.cg.mobile.UI;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobile.DTO.MobileDetails;
import com.cg.mobile.DTO.PurchaseDetails;
import com.cg.mobile.exception.MobileApplicationException;
import com.cg.mobile.service.IMobileService;
import com.cg.mobile.service.MobileServiceImp;

public class MobileUI {

	static Scanner sc= new Scanner(System.in);
	static PurchaseDetails details=null;
	static IMobileService service= new MobileServiceImp();
	
	public static void main(String[] args) throws MobileApplicationException, IOException, SQLException{
		PropertyConfigurator.configure("log4j.properties");
		Logger logger=Logger.getRootLogger();
		System.out.println("Mobile Application");
		System.out.println("********************");
		while(true)
		{
			System.out.println("1.Enter Purchase Details");
			System.out.println("2.Get The Mobile Details");
			System.out.println("3.Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:addPurchasedetails();
			break;
			case 2:getMobileDetails();
			break;
			case 3:
				System.exit(0);
				break;
			
			}
		}
	}



	private static void addPurchasedetails() throws MobileApplicationException {
		PropertyConfigurator.configure("log4j.properties");
		Logger logger=Logger.getRootLogger();
		
		try
		{
		System.out.println("Enter Customer name:");
		String s=sc.next();
		if(service.validateName(s))
		{
			System.out.println("Enter mail Id");
			String mail=sc.next();
		if(service.validateEmailId(mail))
		{
			System.out.println("Enter phone no");
			long phno=sc.nextLong();
			String num=String.valueOf(phno);
		if(service.validPhoneNo(num))
		{
			System.out.println("Enter mobile id");
			int mbid= sc.nextInt(); 
			String id=String.valueOf(mbid);
		if(service.validMobileId(id));
		{
			details= new PurchaseDetails(s,mail,phno,mbid);
		
			int res=service.addPurchaseDetails(details);
			System.out.println(res+"inserted");
			if(res==1)
				System.out.println("value added in database");
			else
				System.out.println("value not added");
		}}}
		}
		logger.info("Executed succefully");
	}
	catch(MobileApplicationException e)
	{
		
		logger.error("Exception occured"+e.getMessage());
	}
}


private static void getMobileDetails() throws IOException, SQLException 
{
	PropertyConfigurator.configure("log4j.properties");
	Logger logger=Logger.getRootLogger();
	
	ArrayList<MobileDetails> list= new ArrayList<MobileDetails>();
	list=service.retrieveDetails();
	for(MobileDetails m:list)
	{
		System.out.println(m.getMobileId());
		System.out.println(m.getName());
		System.out.println(m.getPrice());
		System.out.println(m.getQuantity());
	}
	
	
}
}