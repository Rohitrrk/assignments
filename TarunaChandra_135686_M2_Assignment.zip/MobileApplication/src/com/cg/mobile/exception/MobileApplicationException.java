package com.cg.mobile.exception;

public class MobileApplicationException extends Exception {

	public MobileApplicationException(String message) {
		super(message);
	}

}
