package com.cg.mobile.test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mobile.DAO.IMobileDAO;
import com.cg.mobile.DAO.MobileDaoImp;
import com.cg.mobile.DTO.PurchaseDetails;
import com.cg.mobile.exception.MobileApplicationException;

public class TestMobileApplication {
	static IMobileDAO dao=null;
	static PurchaseDetails bean=null;

	@BeforeClass
	public static void initalize() throws MobileApplicationException
	{
		System.out.println("Hi");
		dao=new MobileDaoImp();
		bean=new PurchaseDetails();
	}

	@Test
	public void test() 
	{
		bean.setcName("123Name");
		bean.setMailId("abc@gmail.com");
		bean.setMobileId(1001);
		bean.setPhoneNo(255822330);
		bean.setPurchaseId(10);
	}
	
	@Test
	public void getDetails() throws IOException, SQLException 
	{
		assertNotNull(dao.retrieveDetails());
	}

}
