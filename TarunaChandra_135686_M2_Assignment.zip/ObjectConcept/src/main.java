
public class Main {

	public static void main(String[] args) {
		Student1 s1= new Student1(111,"abc");
		Student1 s2= new Student1(112,"jkl");
		System.out.println(s1.toString());
		System.out.println(s2.toString());
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		boolean b=s1.equals(s2);
		System.out.println(b);
	}
}
 