import java.util.Scanner;
import java.util.regex.Pattern;


public class Main {

	public static void main(String[] args) throws IFSCcodeMisMatchException {
		BankDetails bd = new BankDetails();
		AccountDetails ad= new AccountDetails();
		Scanner sc = new Scanner(System.in);
		System.out.println("Bank Application\nBank Application Details\n1.Bank Details\n2.Account Details\n3.Exit");
		int ch=sc.nextInt();
		switch(ch)
		{
			case 1:
				bd.BankAccept();
				bd.Bankdisplay();
				break;
			case 2:
				ad.accountAccept();
				ad.accountDisplay();
				break;
			case 3:
				System.exit(0);
		}
	}
	
	
}


class BankDetails
{
	Scanner sc = new Scanner(System.in);
	String bname="";
	String code="";
	String branch="";
	String pattern="[A-Z]{2}[0-9]{6}";
	void BankAccept() 
	{
		System.out.println("Enter the Bank name:");
		bname=sc.next();
		System.out.println("Enter the IFSC code");
		code=sc.next();

		if(Pattern.matches(pattern, code))
			{
			System.out.println("Enter the branch name");
			branch= sc.next();
			} 
		else
			try 
			{
				throw new IFSCcodeMisMatchException(code);
			} 
			catch (IFSCcodeMisMatchException e)
			{
				System.out.println(e);
			   System.exit(0);
			}
	}

	void Bankdisplay()
	{
		System.out.println("Bank name:"+bname+"\nIFSC code:"+code+"\nbranch name:"+branch);
	}
}


class AccountDetails
{
	Scanner sc = new Scanner(System.in);
	int ano;
	String aname="";
	String atype="";
	
	void accountAccept()
	{
		System.out.println("Enter the Account number:");
		ano=sc.nextInt();
		System.out.println("Enter the Account holder name:");
		aname=sc.next();
		System.out.println("Enter the Account type");
		atype= sc.next();
	}
	
	void accountDisplay()
	{
		System.out.println("Account number:"+ano+"\nAccount holder name:"+aname+"\nAccount type:"+atype);
	}
}


class IFSCcodeMisMatchException extends Exception
{
	
	private static final long serialVersionUID = 1L;
	String code;

	public IFSCcodeMisMatchException(String code) {
		super();
		this.code = code;
	}

	public String toString() {
		return "IFSCcodeMisMatchException [Invalid code=" + code + "]";
	}
	
}