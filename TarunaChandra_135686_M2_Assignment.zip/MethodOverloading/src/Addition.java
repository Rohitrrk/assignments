
public class Addition{

	void add(int a, int b)
	{
		System.out.println(a+b);
	}
	void add(double a, double b)
	{
		System.out.println(a+b);
	}
}

class Loading
{
	public static void main(String[] args) {
		Addition x= new Addition();
		x.add(10.0, 20.0);
		x.add(15, 20);
	}
}