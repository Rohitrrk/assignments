
abstract class Shapes {

	abstract void display();
	abstract void show();
	void call()
	{
		System.out.println("Concrete Method");
	}
}

class Circle extends Shapes
{
	void display()
	{
		System.out.println("Circle");
	}

	void show() {
		System.out.println("show circle");
		
	}
}
class Main{
	public static void main(String[] args) {
		Shapes s= new Circle();
		s.display();
		s.show();
		
	}
}



