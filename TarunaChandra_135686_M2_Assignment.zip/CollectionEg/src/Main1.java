import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;


public class Main1 {

	public static void main(String[] args) {
		LinkedHashMap<Integer,String> hm= new LinkedHashMap<Integer,String>();
		hm.put(155, "abc");
		hm.put(110, "def");
		hm.put(143, "xyz");
		hm.put(104, "uvw");
		
		Iterator<Integer> itr=hm.keySet().iterator();
		while(itr.hasNext())
		{
			Integer a= itr.next();
			String v=hm.get(a);
			System.out.println(a+"\t");
			System.out.println(v);
		}
		
		TreeMap<Integer,String> tm= new TreeMap<Integer,String>();
		tm.put(155, null);
		tm.put(110, "def");
		tm.put(143, "xyz");
		tm.put(143, "def");
		System.out.println("-------------------------");
		for(Map.Entry out:tm.entrySet())
		{
			Integer key=(Integer) out.getKey();
			String value= (String) out.getValue();
			System.out.println(key);
			System.out.println(value);
		}
	}
}
