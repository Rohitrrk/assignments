import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;


public class SetEg {

	public static void main(String[] args) {
		/*LinkedHashSet<String> hs= new LinkedHashSet<String>();
		hs.add("One");
		hs.add("four");
		hs.add("Three");
		hs.add("four");
		System.out.println(hs);*/
		
		TreeSet<String> ts= new TreeSet<String>();
		ts.add("one");
		ts.add("four");
		ts.add("three");
		ts.add("four");
		System.out.println(ts);
	}
}
