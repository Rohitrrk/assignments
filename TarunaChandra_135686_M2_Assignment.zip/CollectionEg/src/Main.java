import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;


public class Main {

	public static void main(String[] args) {
		ArrayList<Integer> al= new ArrayList<Integer>();
		al.add(10);
		al.add(20);
		al.add(1);
		al.add(55);
		System.out.println(al);
		Collections.sort(al);
		System.out.println("sorterd array is :"+al);
		ArrayList<Integer> a2= new ArrayList<Integer>();
		al.add(100);
		al.add(20);
		al.add(11);
		al.add(55);
		al.addAll(a2);
		System.out.println(al);
//		al.retainAll(a2);
//		System.out.println(al);
//		al.removeAll(a2);
		int size = al.size();
		System.out.println(size);
		
		Iterator itr=al.iterator();
		while(itr.hasNext())
		{
			int a= (int) itr.next();
			System.out.println(a);
		}
	}
}
