
interface Bike
{
	int a=10;
	void display();
	default void disp()
	{
		System.out.println("its default method");
	}
	static void dim()
	{
		System.out.println("static also can be declared in interface");
	}
}

interface Car extends Bike
{
	void show();
}

interface Auto
{
	void call();
}

class Vehicle implements Bike,Car,Auto
{
	public void call()
	{
		System.out.println("bus interface call method");
	}
	
	public void show()
	{
		System.out.println("car interface call method");
	}
	
	public void display()
	{
		System.out.println("bike interfaec display method");
	}
}


public class InterfaceEg {
	public static void main(String[] args) 
	{
		 Vehicle v=new Vehicle();
		 v.call();
		 v.display();
		 v.call();
		 v.disp();
		 Bike.dim();
	}
}

