import java.util.Arrays;
import java.util.Scanner;


public class ForEachLoop {
	public static void main(String[] args) {
		

	Scanner sc = new Scanner(System.in);
	
	int a[]={10,12,45,0,11};
	Arrays.sort(a);
	System.out.println("sorted array is");
	for(int out:a)
		System.out.println(out);
	
	}
}
