
import java.util.Arrays;
import java.util.Scanner;


public class SortingMaxMin {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the size of array");
		int n=sc.nextInt();;
		int a[]=new int[n];
		
		System.out.println("Enter the elements of array");
		for(int i=0;i<n;i++)
			a[i]=sc.nextInt();
		Arrays.sort(a);
		System.out.println("sorted array is");
		for(int i=0;i<n;i++)
			System.out.println(""+a[i]);
		int min=a[0];
		int max=a[a.length-1];
		System.out.println("maximum amd minimum elements are:"+max+""+min);
	}
}
