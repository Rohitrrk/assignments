
public class VariableArgument {

	public static void fun(int a, String ...b)
	{
		System.out.println(a);
		for(String o:b)
			System.out.println(o);
	}
	public static void main(String[] args) {
		fun(10,"20");
	}
}

