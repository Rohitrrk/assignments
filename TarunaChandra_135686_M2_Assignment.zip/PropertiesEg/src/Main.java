import java.io.IOException;
import java.sql.*;
import javax.sql.*;
	
public class Main {
	
		public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
			Connection conn=DBUtil.getConnection();
			
			PreparedStatement ps=conn.prepareStatement("insert into employee values(?,?)");
			ps.setInt(1, 48);
			ps.setString(2, "Ajit");
			
			int r=ps.executeUpdate();
			System.out.println(r+" rows inserted");
			conn.close();
		}

	}

