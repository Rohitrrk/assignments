
public class InheritanceEg 
{
	String color="blue";
	void brake()
	{
		System.out.println("Super Class Method");
	}
}


class Car extends InheritanceEg
{
	String color="red";
	void gear()
	{
		System.out.println("Sub class method");
		System.out.println(color);
		System.out.println(super.color);
	}
}

class Bike extends Car
{
	void speed()
	{
		String color="black";
		
	}
}


class Main{
	public static void main(String[] args) 
	{
		Car c=new Car();
		InheritanceEg i= new InheritanceEg();
		c.gear();
		c.brake();
		System.out.println(c instanceof Object);
		System.out.println(c instanceof InheritanceEg);
		System.out.println(i instanceof Car);
	
		
	}
}
