import java.util.Scanner;

public class Employee1 
{
		public static void main(String[] args) 
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Employee Id:");
			//int empid=sc.nextInt();
			int empid=Integer.parseInt(sc.nextLine());
			System.out.println("Enter the Employee name:");
			//String ename=sc.next();
			String ename=sc.nextLine();
			System.out.println("Enter Employee salary:");
			int esal=sc.nextInt();
			System.out.println("Enter Employee grade:");
			char grade=sc.next().charAt(0);
			System.out.println("Enter Employee phone no:");
			long phone=sc.nextLong();
			System.out.println("The Employee Details are:\nEmployee ID:"+empid+"\nEmployee name:"+ename+"\nEmployee salary:"+esal+"\nEmployee grade:"+grade+"\nemployee phone no:"+phone);
		}
}
