
public class StringAppend {
public static void main(String[] args) {
	String s="Jessica Miller";
	String a="Amino Acid";
	StringBuffer sb= new StringBuffer();
	sb.append(s.substring(8));
	sb.append(",");
	sb.append(s.substring(0,1));
	System.out.println(sb);
	System.out.print(""+a.substring(6)+","+a.substring(0,5)+"\n");
	System.out.println(""+s);
}
}
