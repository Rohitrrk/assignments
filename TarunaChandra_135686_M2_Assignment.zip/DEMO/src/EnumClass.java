enum directions{
		EAST,SOUTH,NORTH,WEST;
	}
public class EnumClass {

public static void main(String[] args) {
	for(directions s:directions.values())
	System.out.println(s);
}	
}
