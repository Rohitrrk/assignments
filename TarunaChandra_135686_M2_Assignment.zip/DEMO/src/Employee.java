
public class Employee
{
	void display()
	{
		System.out.println("Hello");
	}
	
	static void displayNew()
	{
		System.out.println("Hie");
	}
	public static void main(String[] args) 
	{
		Employee.displayNew();
		
		Employee e= new Employee();
		e.display();
		
		
	}
}
