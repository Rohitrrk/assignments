
public class Client {
	int clientid;
	String clientname;
	String clientaddress;

	Client(int id,String name,String address)
	{
		clientid=id;
		clientname=name;
		clientaddress=address;
	}
	
	Client()
	{
		System.out.println("This is default constructor");
	}
	
	
	void display()
	{
		System.out.println(clientid+" "+clientname+" "+clientaddress);
	}
	
	public static void main(String[] args) 
	{
		Client c1= new Client(101,"adi","Mumbai");
		Client c2=new Client(102,"mani","Chennai");
		Client c3=new Client(103,"frank","US");
		Client c4=new Client();
		Client c5= new Client();
		
		c1.display();
		c2.display();
		c3.display(); 
		c4.display();
		c5.display();
		
	}

}
