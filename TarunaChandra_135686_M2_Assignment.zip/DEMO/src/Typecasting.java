
public class Typecasting {
	public static void main(String[] args) {
		int i=100;
		float l=i;
		System.out.println("This is implicit typecasting");
		System.out.println(l);
		
		double j=100.203;
		int k=(int) j;
		System.out.println("This is explicit typecasting");
		System.out.println(k);
		
	}
}
