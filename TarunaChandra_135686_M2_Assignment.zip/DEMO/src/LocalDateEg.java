import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


public class LocalDateEg {

	public static void main(String[] args) {
		LocalDate d= LocalDate.now();
		LocalDate d1= LocalDate.of(2017, 12, 31);
		System.out.println(d1);
		System.out.println(d);
		System.out.println(d.getYear());
		System.out.println(d.getMonth());
		System.out.println(d.getDayOfMonth());
		System.out.println(d.getDayOfWeek());
		System.out.println(d.plusDays(2));
	
	}
}
