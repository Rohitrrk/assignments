public class Student {
	int rollno;
	String student_name;
	static String collegename="sakec";
	Student()
	{
		
	}
	Student(int r, String n)
	{
		rollno=r;
		student_name=n;
	}
	void display()
	{
		System.out.println(rollno+" "+student_name+" "+collegename);
	}
	
	public static void main(String[] args) {
			Student st1= new Student(101,"abc");
			Student st2=new Student(102,"xyz");
			st1.display();
			st2.display();
	}
}

