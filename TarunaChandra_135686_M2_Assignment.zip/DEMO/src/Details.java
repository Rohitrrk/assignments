
public class Details {

}
