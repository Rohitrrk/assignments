import java.util.Scanner;

public class Person 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First name:");
		String fname= sc.next();
		System.out.println("Enter last name:");
		String lname=sc.next();
		System.out.println("Enter the gender");
		char gender= sc.next().charAt(0);
		System.out.println("Enter the age:");
		int age= sc.nextInt();
		System.out.println("Enter weight:");
		float weight= sc.nextFloat();
		System.out.println("Personal Details:");
		System.out.println("_________________");
		System.out.println("First Name:"+fname+"\nLast Name:"+lname+"\nGender:"+gender+"\nAge:"+age+"\nWeight:"+weight);
	}
}