package com.cg.donation.DTO;
import java.time.LocalDate;


public class DonarDetails {

	private String donarId;
	private String donarName;
	private String phno;
	private String donarAddress;
	private String donationAmount;
	private LocalDate donationDate;
	
	//Getter and Setter
	public String getDonarId() {
		return donarId;
	}
	public void setDonarId(String donarId) {
		this.donarId = donarId;
	}
	public String getDonarName() {
		return donarName;
	}
	public void setDonarName(String donarName) {
		this.donarName = donarName;
	}
	public String getPhno() {
		return phno;
	}
	public void setPhno(String phno) {
		this.phno = phno;
	}
	public String getDonarAddress() {
		return donarAddress;
	}
	public void setDonarAddress(String donarAddress) {
		this.donarAddress = donarAddress;
	}
	public String getDonationAmount() {
		return donationAmount;
	}
	public void setDonationAmount(String donationAmount) {
		this.donationAmount = donationAmount;
	}
	public LocalDate getDonationDate() {
		return donationDate;
	}
	public void setDonationDate(LocalDate donationDate) {
		this.donationDate = donationDate;
	}
	
	//Parameterized Constructor
	public DonarDetails( String donarName, String phno,
			String donarAddress, String donationAmount) {
		super();
		this.donarName = donarName;
		this.phno = phno;
		this.donarAddress = donarAddress;
		this.donationAmount = donationAmount;
	}
	
	//toString method
	public String toString() {
		return "DonarDetails [donarId=" + donarId + ", donarName=" + donarName
				+ ", phno=" + phno + ", donarAddress=" + donarAddress
				+ ", donationAmount=" + donationAmount + ", donationDate="
				+ donationDate + "]";
	}
	
	//default Constructor
	public void DonarDetails ()
	{
		
	}
	
}
