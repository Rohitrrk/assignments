package com.cg.donation.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.donation.DTO.DonarDetails;


public interface IDonationService {

	public int addDonarDetails(DonarDetails d) throws IOException, SQLException;
	public boolean validateName(String name);
	public boolean validateDonarId(String id);
	public boolean validatePhoneNo(String phno);
	public boolean validateAddress(String address);
	public boolean validateDonationAmount(String amnt);
	public ArrayList<DonarDetails> getDetails();
}
