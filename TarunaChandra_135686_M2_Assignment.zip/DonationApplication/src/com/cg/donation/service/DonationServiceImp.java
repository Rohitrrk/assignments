package com.cg.donation.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.donation.DTO.DonarDetails;
import com.cg.donation.dao.DonationDaoImp;
import com.cg.donation.dao.IDonationDAO;


public class DonationServiceImp implements IDonationService{

	IDonationDAO dao=new DonationDaoImp();
	
	public int addDonarDetails(DonarDetails d) throws IOException, SQLException
	{
		return dao.addDonarDetails(d);
	}
	
	
	public boolean validateDonarId(String id)
	{
		String Idptn="[a-z]{2}[0-9]{5}";
		if(Pattern.matches(Idptn, id))
		{
			return true;
		}
		else
		{
			System.out.println("Please Enter valid donar id");
			return false;
		}
	}
	
	public boolean validateName(String Name)
	{
		String pt="[A-Z]{1}[a-z]{2,19}";
		if(Pattern.matches(pt, Name))
		{
			return true;
		}
		else
		{
			System.out.println("Enter valid name");
			return false;
		}
	}
	
	public boolean validatePhoneNo(String phno)
	{
		String ph="[0-9]{10}";
		if(Pattern.matches(ph,phno))
		{
			return true;
		}
		else
		{
			System.out.println("Please Enter valid phone number");
			return false;
		}	
	}
	
	public boolean validateAddress(String address)
	{
		String add="[a-Az-Z]{10,30}";
		if(Pattern.matches(add,address))
		{
			return true;
		}
		else
		{
			System.out.println("Please Enter valid details");
			return false;
		}	
	}
	
	public boolean validateDonationAmount(String amnt)
	{
		String damount="[0-9]{2,}";
		if(Pattern.matches(damount, amnt))
		{
			return true;
		}
		else
		{
			System.out.println("Enter valid amount");
			return false;
		}
	}


	
	
	public ArrayList<DonarDetails> getDetails(DonarDetails d) {
		
		return dao.getDetails(d);
	}


	@Override
	public ArrayList<DonarDetails> getDetails() {
		
		return null;
	}
	
}
