package com.cg.donation.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.donation.DTO.DonarDetails;

public interface IDonationDAO {

	int addDonarDetails(DonarDetails d) throws IOException, SQLException;

	ArrayList<DonarDetails> getDetails(DonarDetails d);

}
