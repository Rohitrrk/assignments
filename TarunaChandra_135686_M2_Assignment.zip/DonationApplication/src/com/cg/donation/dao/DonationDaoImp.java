package com.cg.donation.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.donation.DTO.DonarDetails;
import com.cg.donation.dbutil.DbUtil;


public class DonationDaoImp implements IDonationDAO {

	Connection con= null;
	int res;
	
	public int addDonarDetails(DonarDetails d) throws IOException, SQLException {
		con= DbUtil.getConnection();
		String insertQuery="Insert into donardetails values(donar_seq_id.nextval,?,?,?,?,SYSDATE)";
		PreparedStatement pst=con.prepareStatement(insertQuery);
		pst.setString(1,d.getDonarName());
		pst.setString(2, d.getPhno());
		pst.setString(3,d.getDonarAddress());
		pst.setString(4,d.getDonationAmount());
		
		int res = pst.executeUpdate();
		
		return res;
	}

	@Override
	public ArrayList<DonarDetails> getDetails(DonarDetails d) {
		
		return null;
	}
	
}
