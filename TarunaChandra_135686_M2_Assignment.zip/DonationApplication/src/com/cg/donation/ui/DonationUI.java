package com.cg.donation.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

import com.cg.donation.DTO.DonarDetails;
import com.cg.donation.service.DonationServiceImp;
import com.cg.donation.service.IDonationService;


public class DonationUI {

	static Scanner sc= new Scanner(System.in);
	static DonarDetails dd=null;
	static IDonationService ds= new DonationServiceImp();
	
	
	public static void main(String[] args) throws IOException, SQLException {
		
		System.out.println("Donation Application");
		System.out.println("********************");
		while(true)
		{
			System.out.println("1.add donation details.");
			System.out.println("2.display details");
			System.out.println("3.Exit");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				addDonarDetails();
				break;
//			case 2:
//				displayDonarDetails();
			case 3:
				System.exit(0);
				break;
			}
		}
	
	
	}
	
	
//	private static void displayDonarDetails() {
//		
//		ArrayList<DonarDetails> donar= new ArrayList<DonarDetails>();
//		donar=ds.getDetails();
//		for(DonarDetails d:donar)
//		{
//			System.out.println(d.getDonarName());
//			System.out.println(d.getPhno());
//			System.out.println(d.getDonarAddress());
//			System.out.println(d.getDonationAmount());
//		}
//	}


	public static void addDonarDetails() throws IOException, SQLException
	{
		
		
			System.out.println("Enter the donar name:");
			String name=sc.next();
		if(ds.validateName(name))
		{
			System.out.println("Enter the phone no:");
			String phno=sc.next();
		if(ds.validatePhoneNo(phno))
		{
			System.out.println("Enter the donar Address:");
			String address=sc.next();
		
			System.out.println("Enter the Donation amount");
			int damount=sc.nextInt();
			String damnt=String.valueOf(damount);
		if(ds.validateDonationAmount(damnt))
		{
			dd= new DonarDetails(name,phno,address,damnt);
			
			int result=ds.addDonarDetails(dd);
			System.out.println(result+" inserted");
			if(result==1)
				System.out.println("value added in database");
			else
				System.out.println("value not added");
		}
		
		}}}}		
	
